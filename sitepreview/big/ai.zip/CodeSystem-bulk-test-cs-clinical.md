# Bulk Test CodeSystem � Clinical Observations - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bulk Test CodeSystem � Clinical Observations**

## CodeSystem: Bulk Test CodeSystem � Clinical Observations (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/CodeSystem/bulk-test-cs-clinical | *Version*:0.1.0 |
| Draft as of 2026-04-25 | *Computable Name*:BulkTestCSClinical |

 
Synthetic CodeSystem (Clinical Observations) for IG size testing. Not for clinical use. 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bulk-test-cs-clinical",
  "url" : "http://example.org/fhir/CodeSystem/bulk-test-cs-clinical",
  "version" : "0.1.0",
  "name" : "BulkTestCSClinical",
  "title" : "Bulk Test CodeSystem � Clinical Observations",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-04-25T08:08:13+00:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Synthetic CodeSystem (Clinical Observations) for IG size testing. Not for clinical use.",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 40000,
  "concept" : [{
    "code" : "CLINICAL-000000",
    "display" : "Bulk Clinical Observations concept 0 � 770487",
    "definition" : "Concept 0 in theme clinical. Identifier token d0e8fb19fc5ef267cf3925be0267e4c5aee94f952044c8c2b220daadc9f8ff07. Context markers: w24592 w13278 w46048 w42098 w39256 w28289 w23434 w98696. Sequence 0 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000001",
    "display" : "Bulk Clinical Observations concept 1 � 876646",
    "definition" : "Concept 1 in theme clinical. Identifier token a0b3c1dd6bf6746de366f8225c938936e8d12172b9f3447f59484580e0983788. Context markers: w81482 w21395 w87397 w65302 w14165 w13905 w22280 w38657. Sequence 1 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000002",
    "display" : "Bulk Clinical Observations concept 2 � 343962",
    "definition" : "Concept 2 in theme clinical. Identifier token ff442fc785adb249f3237d6c28ebe6e0071d95e79cf292a315b6b5981a0a89d9. Context markers: w76237 w88907 w13478 w83563 w36062 w95181 w81426 w64987. Sequence 2 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000003",
    "display" : "Bulk Clinical Observations concept 3 � 331148",
    "definition" : "Concept 3 in theme clinical. Identifier token 06809bf1b1ab00cca45111a208da5f8d1d5a4857e5fb405ff9ee5944a702f094. Context markers: w68878 w87236 w46463 w10851 w30926 w65392 w54597 w46421. Sequence 3 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000004",
    "display" : "Bulk Clinical Observations concept 4 � 263032",
    "definition" : "Concept 4 in theme clinical. Identifier token d483021b4fef0b74ea5a4bf09de26ea907e2af6826be85162561cb0d86b63923. Context markers: w38221 w54118 w23396 w22156 w59797 w22676 w57052 w55082. Sequence 4 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000005",
    "display" : "Bulk Clinical Observations concept 5 � 733052",
    "definition" : "Concept 5 in theme clinical. Identifier token 9d9959711dbc8544bcf6daff68e21fe0ada45bef5a89096314a358ceb06f0f09. Context markers: w44671 w15695 w70217 w80284 w26361 w59615 w20328 w82357. Sequence 5 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000006",
    "display" : "Bulk Clinical Observations concept 6 � 407419",
    "definition" : "Concept 6 in theme clinical. Identifier token bbb3c11e29cc5f9bfa7d70a76211cd58c5589045995f7a531ec63702d66bbdad. Context markers: w92397 w91070 w57400 w85674 w35203 w19116 w16006 w96673. Sequence 6 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000007",
    "display" : "Bulk Clinical Observations concept 7 � 338968",
    "definition" : "Concept 7 in theme clinical. Identifier token c7c45f4ef4878bd8c96b96e29f0891c9a11256b79ae3905505bdec53a4e5d34a. Context markers: w47930 w20458 w40512 w23238 w59823 w46434 w69429 w93320. Sequence 7 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000008",
    "display" : "Bulk Clinical Observations concept 8 � 974628",
    "definition" : "Concept 8 in theme clinical. Identifier token f650d94c9376f6d7d8599177a00a0d4b34016e34116a43054dcfc06649dfb461. Context markers: w57819 w31319 w58520 w56566 w37460 w97841 w44993 w99593. Sequence 8 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000009",
    "display" : "Bulk Clinical Observations concept 9 � 779514",
    "definition" : "Concept 9 in theme clinical. Identifier token 5dea15fb7db597ab55cc3a5ba9839161c83b77b27b3d4018435275b6d6ed4957. Context markers: w19358 w89840 w93227 w32431 w80010 w42087 w31417 w70589. Sequence 9 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000010",
    "display" : "Bulk Clinical Observations concept 10 � 497887",
    "definition" : "Concept 10 in theme clinical. Identifier token 6db500a4f0ac057489ded7fa91787b367fe1491270cf3e725d15c9b39c239013. Context markers: w45382 w93886 w83000 w38785 w99733 w52504 w17331 w40021. Sequence 10 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000011",
    "display" : "Bulk Clinical Observations concept 11 � 961722",
    "definition" : "Concept 11 in theme clinical. Identifier token 107319079621598352960be82f5468662b5d11f4405097aca72027e74cfe4577. Context markers: w14207 w51347 w62581 w45093 w18675 w37653 w84341 w51245. Sequence 11 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000012",
    "display" : "Bulk Clinical Observations concept 12 � 322955",
    "definition" : "Concept 12 in theme clinical. Identifier token dc3c61a52d77a03ffc444813caac963571c82382541a31cf6f6e85a269693b62. Context markers: w95909 w75435 w61856 w94259 w70142 w28726 w44718 w28301. Sequence 12 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000013",
    "display" : "Bulk Clinical Observations concept 13 � 358607",
    "definition" : "Concept 13 in theme clinical. Identifier token df1b7ee4d8d14f9b6a60a3c0ae818c4c605f54c26ad44faffd1ae080d820d0b8. Context markers: w83579 w80644 w44438 w86622 w66155 w86484 w62350 w57447. Sequence 13 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000014",
    "display" : "Bulk Clinical Observations concept 14 � 329974",
    "definition" : "Concept 14 in theme clinical. Identifier token f1de866565b2a6258a819415a01fb0c87ca80cd7edcb09db10d473d3697c9205. Context markers: w28131 w76784 w74686 w21915 w16175 w24371 w30033 w92240. Sequence 14 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000015",
    "display" : "Bulk Clinical Observations concept 15 � 267753",
    "definition" : "Concept 15 in theme clinical. Identifier token 6d27b8f37af2f91f6ce30d2fc2b3db9567834109a15b13150023190564abda65. Context markers: w99192 w65333 w88172 w18326 w60432 w60019 w88104 w71348. Sequence 15 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000016",
    "display" : "Bulk Clinical Observations concept 16 � 654816",
    "definition" : "Concept 16 in theme clinical. Identifier token dc54bbc069444128d4bb3e0ba6b4e784988fc89570f0dc40e3fdcdbcb7baabc5. Context markers: w42953 w82512 w11504 w99166 w25014 w99353 w80381 w44973. Sequence 16 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000017",
    "display" : "Bulk Clinical Observations concept 17 � 905934",
    "definition" : "Concept 17 in theme clinical. Identifier token b9938aac77917543dcf3439380875454d14b59449b720ae9c52bb1c4be7e8dc4. Context markers: w94012 w54587 w24621 w48469 w66985 w30730 w69470 w10425. Sequence 17 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000018",
    "display" : "Bulk Clinical Observations concept 18 � 857168",
    "definition" : "Concept 18 in theme clinical. Identifier token e51c8070c7996c8628026a4548547544db762e9505c78a64c8e6c646c80d6b38. Context markers: w44522 w75612 w33416 w76542 w23947 w91959 w49117 w93748. Sequence 18 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000019",
    "display" : "Bulk Clinical Observations concept 19 � 632323",
    "definition" : "Concept 19 in theme clinical. Identifier token cc084cba398dc15f38495c77117c80af98fe2f85117bdbf5ddb0c1836fc5d28b. Context markers: w89818 w36071 w30032 w59009 w31174 w80697 w79514 w10074. Sequence 19 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000020",
    "display" : "Bulk Clinical Observations concept 20 � 728038",
    "definition" : "Concept 20 in theme clinical. Identifier token d43027111610a35527a347caa0ca0bbf28c302f8613e8c73acbfd93d19b1bf54. Context markers: w52487 w74042 w12552 w24662 w57576 w50306 w41385 w17592. Sequence 20 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000021",
    "display" : "Bulk Clinical Observations concept 21 � 352572",
    "definition" : "Concept 21 in theme clinical. Identifier token eb5f3522c317342d5f46436e864554e97c86a4da0497080a932a10e894f156c6. Context markers: w84364 w20322 w21226 w73699 w19071 w79822 w26483 w26828. Sequence 21 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000022",
    "display" : "Bulk Clinical Observations concept 22 � 791798",
    "definition" : "Concept 22 in theme clinical. Identifier token 3d6308e7c6f014fb4e5752ee7dc6ad693e582b892ea579a1970634a87586164d. Context markers: w72296 w82063 w31643 w44741 w79163 w89507 w65461 w37760. Sequence 22 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000023",
    "display" : "Bulk Clinical Observations concept 23 � 665492",
    "definition" : "Concept 23 in theme clinical. Identifier token 8ec68ec372f54a4990743a9f6d219f330f2a8895ca6e9e875934b01ce127ff37. Context markers: w36365 w50857 w62296 w98039 w95180 w58944 w67422 w77839. Sequence 23 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000024",
    "display" : "Bulk Clinical Observations concept 24 � 573417",
    "definition" : "Concept 24 in theme clinical. Identifier token 2b8abcd209c3f9eeed0310e82e3277fb81d5146a17e43ecf0161844ad73bdbf8. Context markers: w25860 w42493 w39451 w18392 w54313 w12757 w87110 w82603. Sequence 24 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000025",
    "display" : "Bulk Clinical Observations concept 25 � 341292",
    "definition" : "Concept 25 in theme clinical. Identifier token 4769c97ec2733fdf783e7a41e438929ae5724c7af777fdfa9f7942b13823cb33. Context markers: w87128 w38864 w10942 w19305 w92719 w17716 w40007 w18834. Sequence 25 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000026",
    "display" : "Bulk Clinical Observations concept 26 � 132938",
    "definition" : "Concept 26 in theme clinical. Identifier token bdc8cc37d8494648c82c7b6f42797259abfefc3660dcc9554c18e8897f7e1ece. Context markers: w53309 w19287 w77391 w41195 w46500 w97684 w73624 w38080. Sequence 26 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000027",
    "display" : "Bulk Clinical Observations concept 27 � 665427",
    "definition" : "Concept 27 in theme clinical. Identifier token 77e2b948a14bb7ccfc40ff7394599dc2dfffe528f655a9bea43ecd87d7ace0be. Context markers: w27342 w84847 w85525 w71953 w41850 w71993 w63354 w34957. Sequence 27 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000028",
    "display" : "Bulk Clinical Observations concept 28 � 198907",
    "definition" : "Concept 28 in theme clinical. Identifier token 3cf59c94508ca88bd1ea30d4d5f4f7c870cdf4128f54d11e1ab7caa81461ccbf. Context markers: w22704 w96374 w66498 w56438 w65519 w63883 w71213 w17100. Sequence 28 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000029",
    "display" : "Bulk Clinical Observations concept 29 � 806073",
    "definition" : "Concept 29 in theme clinical. Identifier token de15e2cebb9fa520745527d5b6bbdad365832d718f5bae63799c1d977a67f4e8. Context markers: w95649 w94696 w22899 w17944 w62772 w54473 w24322 w42591. Sequence 29 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000030",
    "display" : "Bulk Clinical Observations concept 30 � 300896",
    "definition" : "Concept 30 in theme clinical. Identifier token 99c8f1324ef27030a57868279c8b0f042328806686fae3c79b0b4f9e13c28284. Context markers: w34931 w80292 w68800 w28373 w65296 w34050 w46509 w70637. Sequence 30 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000031",
    "display" : "Bulk Clinical Observations concept 31 � 361941",
    "definition" : "Concept 31 in theme clinical. Identifier token f7d6eae0f5409f2fb58455a64b745ee6ad8f2658bee5612fe7740558fc3974be. Context markers: w19880 w68082 w82132 w22833 w16630 w95477 w80855 w11934. Sequence 31 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000032",
    "display" : "Bulk Clinical Observations concept 32 � 197793",
    "definition" : "Concept 32 in theme clinical. Identifier token d2bcbaa6234d2d7b34de9e793992b82cbbd4409a81123440f874c07c89413c0c. Context markers: w40982 w31798 w63269 w73653 w73092 w38016 w62565 w17685. Sequence 32 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000033",
    "display" : "Bulk Clinical Observations concept 33 � 272634",
    "definition" : "Concept 33 in theme clinical. Identifier token e8f3a711a52bc0c9d54641a08b6a846b8fb2fb145fdf223991910b10f8cba537. Context markers: w59672 w10282 w61173 w44760 w69638 w47388 w65444 w82845. Sequence 33 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000034",
    "display" : "Bulk Clinical Observations concept 34 � 794022",
    "definition" : "Concept 34 in theme clinical. Identifier token 8308135ac86b2f6649af5910517e456bb24ed9d05e9db5bfb7a03c60f07d9680. Context markers: w73788 w30289 w34890 w48890 w38534 w17665 w85914 w81066. Sequence 34 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000035",
    "display" : "Bulk Clinical Observations concept 35 � 163918",
    "definition" : "Concept 35 in theme clinical. Identifier token 692f19ca3631d315fd011ca251f3e9865e1d49a50902e135c354c158ea26b05a. Context markers: w51104 w17492 w16572 w86569 w72493 w75909 w79615 w30635. Sequence 35 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000036",
    "display" : "Bulk Clinical Observations concept 36 � 159642",
    "definition" : "Concept 36 in theme clinical. Identifier token 1cc96d87cab5cae50135fbc9de34cb93347e73809148458d632b6e2816ffb085. Context markers: w76562 w20500 w34356 w18981 w87992 w18907 w98501 w40828. Sequence 36 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000037",
    "display" : "Bulk Clinical Observations concept 37 � 523389",
    "definition" : "Concept 37 in theme clinical. Identifier token d1dc925d69eab9b255e4d27a6c5778de76769d093beda93d43d78324525915d4. Context markers: w25713 w84668 w42271 w85880 w87924 w15209 w91183 w20745. Sequence 37 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000038",
    "display" : "Bulk Clinical Observations concept 38 � 539589",
    "definition" : "Concept 38 in theme clinical. Identifier token 295da65bfa5cdee642bc2cf70e1d9d8528d26367106a6489ddec8e4a5634ee9d. Context markers: w96163 w86503 w84085 w78522 w51467 w44179 w36772 w97782. Sequence 38 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000039",
    "display" : "Bulk Clinical Observations concept 39 � 850981",
    "definition" : "Concept 39 in theme clinical. Identifier token 0640d65467550e8752bafbe4bb88a6b71d78d457af9523ffba42b669a24e289c. Context markers: w51180 w41285 w44814 w61876 w27154 w98039 w94607 w49321. Sequence 39 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000040",
    "display" : "Bulk Clinical Observations concept 40 � 579434",
    "definition" : "Concept 40 in theme clinical. Identifier token c683fc70807463bb5594eb98c0acd723dc29f0d2bf78e9ad7a80f6be71948739. Context markers: w51441 w19508 w11220 w70068 w91416 w83792 w23104 w19602. Sequence 40 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000041",
    "display" : "Bulk Clinical Observations concept 41 � 663750",
    "definition" : "Concept 41 in theme clinical. Identifier token 34c35ebbf1785d7fbfe9d025c31b8456445551019d445dedc4fe8e7a0ffad97c. Context markers: w37938 w76307 w44760 w27361 w55745 w19016 w42018 w58434. Sequence 41 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000042",
    "display" : "Bulk Clinical Observations concept 42 � 398830",
    "definition" : "Concept 42 in theme clinical. Identifier token 944bbeb1691b211c99b4fc4f9b1d9fcc67301f0734e0abbc53ad84997e431cce. Context markers: w30676 w67433 w81200 w49651 w90173 w95717 w79329 w11025. Sequence 42 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000043",
    "display" : "Bulk Clinical Observations concept 43 � 800305",
    "definition" : "Concept 43 in theme clinical. Identifier token 3fe3c492533ec33202fe9b87e8b17404aaaa832ef3c70592a2bf949422f1efd4. Context markers: w82692 w49240 w96951 w23577 w27601 w44664 w25129 w24029. Sequence 43 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000044",
    "display" : "Bulk Clinical Observations concept 44 � 878480",
    "definition" : "Concept 44 in theme clinical. Identifier token a53575aed38ae81b08096af9d78da9253ad3ecef4f3c1f8b61958e41c6551056. Context markers: w82512 w30374 w45697 w46930 w89276 w37607 w54942 w36685. Sequence 44 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000045",
    "display" : "Bulk Clinical Observations concept 45 � 820892",
    "definition" : "Concept 45 in theme clinical. Identifier token 6a60c7107a206fcead1a83ed10f1f29bf6e281012287feb44f8d096d39a9d64d. Context markers: w93130 w44600 w76244 w74032 w42914 w16658 w22097 w93136. Sequence 45 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000046",
    "display" : "Bulk Clinical Observations concept 46 � 544151",
    "definition" : "Concept 46 in theme clinical. Identifier token ba5ebb07e67da977632b9fb34332ef1807d7b30af90ab17210f6da877007cead. Context markers: w46265 w15778 w10464 w53719 w27146 w93507 w44335 w31178. Sequence 46 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000047",
    "display" : "Bulk Clinical Observations concept 47 � 877236",
    "definition" : "Concept 47 in theme clinical. Identifier token 42374e1a51018bd593ac6b03c73b40c75016b20537addbdea91986c4a32a13db. Context markers: w67912 w82309 w66057 w83519 w11267 w24663 w19862 w29536. Sequence 47 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000048",
    "display" : "Bulk Clinical Observations concept 48 � 672092",
    "definition" : "Concept 48 in theme clinical. Identifier token fffdbcf4a2156e056a388943eb7da1264275ee02d7a32f5fcd1bbeedbb2f5718. Context markers: w14722 w58393 w86350 w82420 w29410 w66333 w26704 w15482. Sequence 48 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000049",
    "display" : "Bulk Clinical Observations concept 49 � 423232",
    "definition" : "Concept 49 in theme clinical. Identifier token 41ac750a7f14583c278d4698787e821c1b0e551b82c4d71b59332796671a19d5. Context markers: w57795 w15229 w56898 w37535 w99399 w42706 w97416 w23473. Sequence 49 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000050",
    "display" : "Bulk Clinical Observations concept 50 � 470858",
    "definition" : "Concept 50 in theme clinical. Identifier token 58e37b7dbdfa1966e344e7d899182f6b0938d9ed3737ff4774072fd03fa27ebc. Context markers: w83385 w63264 w91351 w30257 w41029 w31299 w33206 w64040. Sequence 50 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000051",
    "display" : "Bulk Clinical Observations concept 51 � 125990",
    "definition" : "Concept 51 in theme clinical. Identifier token 26c4d117572cfe38240d894fb3b66ea194b23bf14a4f27fbd4d5926909e2c079. Context markers: w33509 w53540 w63964 w97806 w42527 w44970 w30866 w24168. Sequence 51 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000052",
    "display" : "Bulk Clinical Observations concept 52 � 501124",
    "definition" : "Concept 52 in theme clinical. Identifier token d55eb79fb9b818743ce46a3523e220e5ae5614f9d9aa73acb000546bf44cf171. Context markers: w15075 w71694 w39154 w36158 w70332 w55830 w50001 w39831. Sequence 52 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000053",
    "display" : "Bulk Clinical Observations concept 53 � 333752",
    "definition" : "Concept 53 in theme clinical. Identifier token a447d913c0ff52a22b08c755c550411ba5b2ec252ea72c2b67d8a42600a8b7b9. Context markers: w13101 w96511 w35313 w62227 w53025 w46517 w19099 w46585. Sequence 53 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000054",
    "display" : "Bulk Clinical Observations concept 54 � 468203",
    "definition" : "Concept 54 in theme clinical. Identifier token 4eee6308c32239e25c3df06b0a5a5ee6e46bff505535861be30be727a3729cb5. Context markers: w94080 w76768 w62386 w99065 w80282 w53404 w13617 w25118. Sequence 54 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000055",
    "display" : "Bulk Clinical Observations concept 55 � 373903",
    "definition" : "Concept 55 in theme clinical. Identifier token 4b16fa3e26fea34144e2f29bef250702f2451254c52da84d94f1978df3939df4. Context markers: w33405 w86099 w44795 w15014 w24208 w88193 w66959 w55309. Sequence 55 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000056",
    "display" : "Bulk Clinical Observations concept 56 � 863934",
    "definition" : "Concept 56 in theme clinical. Identifier token ea114f74202ac602521f531a13131f81b6f931bebcaf44fea1e44467480bbd24. Context markers: w51114 w67199 w89457 w77033 w25157 w60488 w85574 w34914. Sequence 56 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000057",
    "display" : "Bulk Clinical Observations concept 57 � 367095",
    "definition" : "Concept 57 in theme clinical. Identifier token e54b7ed02eb7ccbf808fc90f61654c0493c73562900f537f09954308099a1ff3. Context markers: w15817 w67154 w10221 w78146 w80575 w97900 w35825 w57739. Sequence 57 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000058",
    "display" : "Bulk Clinical Observations concept 58 � 552248",
    "definition" : "Concept 58 in theme clinical. Identifier token a3df69eacb2e94402594ab4bf2d4c57f5dc3a7fd37bf632757804de547e98efb. Context markers: w19171 w97062 w53279 w91678 w51145 w96951 w26334 w49363. Sequence 58 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000059",
    "display" : "Bulk Clinical Observations concept 59 � 631756",
    "definition" : "Concept 59 in theme clinical. Identifier token 171de0926fe6bc5cff37d7acb50b6fb67d82ac61e56834635cfa246020ad0505. Context markers: w50538 w97410 w63528 w52753 w62743 w48752 w82667 w26683. Sequence 59 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000060",
    "display" : "Bulk Clinical Observations concept 60 � 301158",
    "definition" : "Concept 60 in theme clinical. Identifier token 48d9c7cdafb69a1d173baa90dfbb1d81e754310d618108a398aac56ce5b5d3a3. Context markers: w65108 w97153 w59695 w98777 w32810 w90676 w84593 w49446. Sequence 60 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000061",
    "display" : "Bulk Clinical Observations concept 61 � 525800",
    "definition" : "Concept 61 in theme clinical. Identifier token fbe014e6757b12f34fdeb2101d8ea7a61218bf7d311dac4a0cf021b365cdce34. Context markers: w81819 w10053 w49829 w47606 w37549 w66346 w86019 w89516. Sequence 61 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000062",
    "display" : "Bulk Clinical Observations concept 62 � 786508",
    "definition" : "Concept 62 in theme clinical. Identifier token 0cc82bd6110175443dc2fb96d5e20535ce1726d980c9517396d280483ad8ebdb. Context markers: w52237 w70946 w67905 w67954 w98555 w38010 w77000 w72021. Sequence 62 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000063",
    "display" : "Bulk Clinical Observations concept 63 � 932291",
    "definition" : "Concept 63 in theme clinical. Identifier token bd5f25c8ea3e5d7acadcfd55cc22666a312a95d9fbb1fd963bd6009fdb91ed8a. Context markers: w32241 w96356 w21114 w47196 w77561 w97012 w92960 w91167. Sequence 63 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000064",
    "display" : "Bulk Clinical Observations concept 64 � 451470",
    "definition" : "Concept 64 in theme clinical. Identifier token 508ea04f94c6a467efe719ee1707b000014f40f5409b6bf7a4a09b6e16d5a129. Context markers: w22240 w40784 w98184 w50687 w39444 w36100 w29313 w13201. Sequence 64 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000065",
    "display" : "Bulk Clinical Observations concept 65 � 148458",
    "definition" : "Concept 65 in theme clinical. Identifier token 08a0777bd4e474a81d5f2dff9c5578334a23ced4a979a1653f147a6c07a9a6b2. Context markers: w42092 w72277 w90120 w19545 w69692 w64321 w92544 w85454. Sequence 65 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000066",
    "display" : "Bulk Clinical Observations concept 66 � 303880",
    "definition" : "Concept 66 in theme clinical. Identifier token f0bc8c43f316de8a5c0919038d721f6143d5f2d9aa6f57a9a9bf34b588c4d50f. Context markers: w60328 w74799 w62383 w41979 w29342 w95990 w10726 w23970. Sequence 66 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000067",
    "display" : "Bulk Clinical Observations concept 67 � 916232",
    "definition" : "Concept 67 in theme clinical. Identifier token 937b42a491fae83428da08334623d145efdea0ccf32fbdad63aae3bd5fa43ddb. Context markers: w65724 w38683 w33053 w77889 w70889 w16582 w83060 w42662. Sequence 67 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000068",
    "display" : "Bulk Clinical Observations concept 68 � 989545",
    "definition" : "Concept 68 in theme clinical. Identifier token 38f26c6e0b4f86cc137e7d87ab8a45b48ff9a8848f11d122fb0c41d968c64850. Context markers: w25906 w69829 w27477 w70901 w97500 w79616 w83259 w88047. Sequence 68 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000069",
    "display" : "Bulk Clinical Observations concept 69 � 432711",
    "definition" : "Concept 69 in theme clinical. Identifier token 2798baca2719f7986a2f66a2a2f339e9b63c935ce110a6666ee4c42b2f85b3d6. Context markers: w68008 w90301 w76162 w65933 w81810 w68446 w30861 w72216. Sequence 69 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000070",
    "display" : "Bulk Clinical Observations concept 70 � 571932",
    "definition" : "Concept 70 in theme clinical. Identifier token 9c4a7813b2a7341201a49e8b46c6fdbcebf512edeabd5ef5aeed94ca775134dd. Context markers: w43972 w42406 w93579 w46347 w78327 w73517 w92149 w41358. Sequence 70 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000071",
    "display" : "Bulk Clinical Observations concept 71 � 387936",
    "definition" : "Concept 71 in theme clinical. Identifier token 80f9fc0c095ddc3898a20d97b8c01b304bf5cc1a8336ce55739bd1172b410bfd. Context markers: w67654 w20155 w47450 w40735 w45614 w54020 w51904 w80798. Sequence 71 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000072",
    "display" : "Bulk Clinical Observations concept 72 � 184491",
    "definition" : "Concept 72 in theme clinical. Identifier token ca069264e737a7ff7abda8e6501b719f0a1274eede2abdd8b7b8c2627e631f30. Context markers: w28136 w29769 w40311 w60205 w30028 w38043 w18418 w64377. Sequence 72 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000073",
    "display" : "Bulk Clinical Observations concept 73 � 527398",
    "definition" : "Concept 73 in theme clinical. Identifier token 799fe1c8764ec2052ba4b6ea9b26021694eac635c212c2e26f79e66e425b447a. Context markers: w53369 w81121 w71069 w64496 w18161 w37110 w65069 w61049. Sequence 73 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000074",
    "display" : "Bulk Clinical Observations concept 74 � 907189",
    "definition" : "Concept 74 in theme clinical. Identifier token 540c9fdc717b3c0f95036a4e0f5432bc6952592a6f10cdc3419967a5274c0729. Context markers: w86556 w12560 w85456 w59857 w72518 w10772 w56105 w49139. Sequence 74 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000075",
    "display" : "Bulk Clinical Observations concept 75 � 890075",
    "definition" : "Concept 75 in theme clinical. Identifier token fe3970c4817a885d498eb467e3e1d7fc5b63112e9c82f78f41630beac264a730. Context markers: w61116 w64921 w80545 w81582 w89069 w38906 w73993 w38760. Sequence 75 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000076",
    "display" : "Bulk Clinical Observations concept 76 � 386193",
    "definition" : "Concept 76 in theme clinical. Identifier token ea674f8864a6909ab7c96c3a2eec88130b6c4e0bd216dad5d1ff1c4e3f263bae. Context markers: w67125 w73654 w13804 w60968 w54057 w97670 w99016 w62994. Sequence 76 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000077",
    "display" : "Bulk Clinical Observations concept 77 � 859359",
    "definition" : "Concept 77 in theme clinical. Identifier token 725f23c96d727f28981d87bbe2c3adf56c05ba251ead81c4ff2126f6a2d0745e. Context markers: w31632 w71261 w26728 w91560 w80008 w13534 w61645 w87580. Sequence 77 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000078",
    "display" : "Bulk Clinical Observations concept 78 � 691807",
    "definition" : "Concept 78 in theme clinical. Identifier token 45a4c0670c7d762d90cca477e11a7c33fd9827d68dcb297306d47cc12c816f10. Context markers: w96900 w13552 w21003 w94246 w66179 w27786 w70515 w33819. Sequence 78 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000079",
    "display" : "Bulk Clinical Observations concept 79 � 152727",
    "definition" : "Concept 79 in theme clinical. Identifier token e4d6c46718cef4640c4f82ee66dd73ae9b7966fb0ad16e299a1ca55d6fdf7ce2. Context markers: w44099 w59689 w52906 w37742 w69598 w52840 w54236 w59692. Sequence 79 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000080",
    "display" : "Bulk Clinical Observations concept 80 � 391773",
    "definition" : "Concept 80 in theme clinical. Identifier token 97cf9c02cfd0a1c3cc1045479aa2a7d704875bd00ec7f4fb5ef3c89df3b64e6d. Context markers: w65255 w43065 w20735 w71644 w12540 w80702 w16826 w55870. Sequence 80 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000081",
    "display" : "Bulk Clinical Observations concept 81 � 335113",
    "definition" : "Concept 81 in theme clinical. Identifier token 6ee68dce5c0aac819c34e0576a8d800e26da18073ef8896126a01d5292ac9ef8. Context markers: w95215 w18993 w95426 w15276 w14067 w42411 w36130 w12671. Sequence 81 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000082",
    "display" : "Bulk Clinical Observations concept 82 � 751517",
    "definition" : "Concept 82 in theme clinical. Identifier token 7314a183551ad02a54af8e7f975f856e7fb04f2cfe3782dd5c764116b7f86fa3. Context markers: w29973 w41266 w26544 w72070 w97747 w24993 w83920 w38569. Sequence 82 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000083",
    "display" : "Bulk Clinical Observations concept 83 � 587623",
    "definition" : "Concept 83 in theme clinical. Identifier token 84ba6d2955146423cbed2eba0fc7c05cf5e2a92a2fa24edff0d3357f52f1660a. Context markers: w43586 w58351 w31992 w89415 w89593 w25012 w31465 w50768. Sequence 83 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000084",
    "display" : "Bulk Clinical Observations concept 84 � 213349",
    "definition" : "Concept 84 in theme clinical. Identifier token a991e119f5e4babc9c8795e78778bac41b6fb318a29d483fc9f293ab8030f8b0. Context markers: w85849 w13365 w50888 w85470 w98781 w59192 w61990 w35995. Sequence 84 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000085",
    "display" : "Bulk Clinical Observations concept 85 � 179688",
    "definition" : "Concept 85 in theme clinical. Identifier token 65e7cde30755c4f5311d086352c1d632b605e1679b07177eab8fc1c7b43173dc. Context markers: w87607 w92213 w41830 w23356 w49529 w99687 w88697 w25866. Sequence 85 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000086",
    "display" : "Bulk Clinical Observations concept 86 � 934904",
    "definition" : "Concept 86 in theme clinical. Identifier token eed84569523ad1e9dd3e4bf3715975b9725cd5308ec96c22bf9766b89eaa7ecc. Context markers: w84177 w15383 w55508 w79827 w66148 w96706 w58571 w19038. Sequence 86 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000087",
    "display" : "Bulk Clinical Observations concept 87 � 630538",
    "definition" : "Concept 87 in theme clinical. Identifier token 077f92f744bc2b5a7470e682303d295be0a76a790a9b905e7ad71c2bd9f2983c. Context markers: w94874 w54725 w11658 w65057 w74251 w23833 w66822 w57472. Sequence 87 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000088",
    "display" : "Bulk Clinical Observations concept 88 � 766459",
    "definition" : "Concept 88 in theme clinical. Identifier token cf6d777a11afdd91e341022a60bdbed837f72edf3e6f2931147d4caf20c41848. Context markers: w70258 w30052 w67080 w33086 w78386 w95256 w45400 w90728. Sequence 88 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000089",
    "display" : "Bulk Clinical Observations concept 89 � 947458",
    "definition" : "Concept 89 in theme clinical. Identifier token 1d53a497fa66dacc379f04df2b91d41be6d4063f42dbf6cb869df44eb6e91e97. Context markers: w80539 w73372 w70931 w67091 w87656 w45179 w52245 w42177. Sequence 89 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000090",
    "display" : "Bulk Clinical Observations concept 90 � 971084",
    "definition" : "Concept 90 in theme clinical. Identifier token 1d2b0e30c44eed10538ba48d1092294f05f29edd85d41aa8a19f79d44300ebdc. Context markers: w21359 w46559 w69087 w41963 w70910 w84691 w89997 w97580. Sequence 90 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000091",
    "display" : "Bulk Clinical Observations concept 91 � 497399",
    "definition" : "Concept 91 in theme clinical. Identifier token 90c60cdaea466c630af4b94f209df96127248a84579a5556e91f4960e47f1cfd. Context markers: w54092 w13761 w74789 w52600 w33834 w73904 w37802 w56507. Sequence 91 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000092",
    "display" : "Bulk Clinical Observations concept 92 � 936587",
    "definition" : "Concept 92 in theme clinical. Identifier token 8de6a09dc456f3a893421a2d90cf9867cc9c9353d48e917e151835c6d315e9bd. Context markers: w43862 w54608 w46655 w88139 w46211 w82848 w11330 w77715. Sequence 92 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000093",
    "display" : "Bulk Clinical Observations concept 93 � 300337",
    "definition" : "Concept 93 in theme clinical. Identifier token 82be2c67b1c63d9bf37202a51fb74346429c1b3f821d53dd964dbfc9a7d77673. Context markers: w21221 w41635 w63271 w74038 w82768 w41499 w72402 w94659. Sequence 93 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000094",
    "display" : "Bulk Clinical Observations concept 94 � 846420",
    "definition" : "Concept 94 in theme clinical. Identifier token 2dbd3297728f30ca19e12f0950201be92b8dfbd0f26f44859826c86ff4aaaf4c. Context markers: w74332 w68743 w12260 w22196 w48566 w39045 w63005 w41890. Sequence 94 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000095",
    "display" : "Bulk Clinical Observations concept 95 � 421080",
    "definition" : "Concept 95 in theme clinical. Identifier token 2d4871aea89b905275249925708f3ba2ccc5a9c902aeaad866c5a55bb41d2918. Context markers: w97026 w86225 w58368 w72031 w82544 w79588 w55056 w65771. Sequence 95 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000096",
    "display" : "Bulk Clinical Observations concept 96 � 882169",
    "definition" : "Concept 96 in theme clinical. Identifier token 044e3e8917337bbc1719b9010bded55c495abe832820eb590dd3a98203df8cf4. Context markers: w82140 w53357 w56112 w69473 w45509 w50189 w42951 w40217. Sequence 96 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000097",
    "display" : "Bulk Clinical Observations concept 97 � 226516",
    "definition" : "Concept 97 in theme clinical. Identifier token e97fcfa920490c0edcab8d4f46f1db186adde86fce186d3fe7a877db9b7dcda7. Context markers: w35242 w51359 w25670 w80236 w34267 w35105 w38361 w73464. Sequence 97 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000098",
    "display" : "Bulk Clinical Observations concept 98 � 389930",
    "definition" : "Concept 98 in theme clinical. Identifier token d5fa8bac60d72cbd39e0e4cb7b5c0522685c0c62d31087112406c12b9cdb5038. Context markers: w87278 w78765 w88222 w47093 w23176 w35443 w48829 w39816. Sequence 98 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000099",
    "display" : "Bulk Clinical Observations concept 99 � 478411",
    "definition" : "Concept 99 in theme clinical. Identifier token e307122e515a8096edf5429b0c5a3b7e036d36b68dbfed821951a4823e5f3dd4. Context markers: w33519 w49618 w11854 w80010 w26591 w45954 w15965 w17146. Sequence 99 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000100",
    "display" : "Bulk Clinical Observations concept 100 � 680238",
    "definition" : "Concept 100 in theme clinical. Identifier token a6bb31bc61f4d07a1518376cf217b5c8f75d78682197bd61071df421f601a828. Context markers: w48290 w26551 w93606 w74340 w23446 w11607 w85243 w47268. Sequence 100 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000101",
    "display" : "Bulk Clinical Observations concept 101 � 592198",
    "definition" : "Concept 101 in theme clinical. Identifier token ad51a093fd84028f53a584655bb4d74499e8824b4e0b46f6d0238d976ca09bd6. Context markers: w72746 w67733 w54657 w34164 w16734 w43092 w72616 w24953. Sequence 101 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000102",
    "display" : "Bulk Clinical Observations concept 102 � 962050",
    "definition" : "Concept 102 in theme clinical. Identifier token a57c776ac9d90a1e80e4a3edd4f5b2347e2912fcd7b70e6d09f97b7ef6dbb5cf. Context markers: w18564 w62521 w74454 w19710 w85631 w92502 w99974 w17026. Sequence 102 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000103",
    "display" : "Bulk Clinical Observations concept 103 � 259097",
    "definition" : "Concept 103 in theme clinical. Identifier token d064cf0fe4055f12c41f450e948758fab978ebdf0e82a6df180c05da004bbcdb. Context markers: w29555 w83772 w49824 w21164 w42530 w25525 w83147 w64548. Sequence 103 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000104",
    "display" : "Bulk Clinical Observations concept 104 � 735770",
    "definition" : "Concept 104 in theme clinical. Identifier token 11aa98e119b810e208d015636bf634d7716c3a0d9f70f894f5573e52ce25c428. Context markers: w88135 w91057 w39581 w78494 w59856 w69049 w68028 w48974. Sequence 104 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000105",
    "display" : "Bulk Clinical Observations concept 105 � 717113",
    "definition" : "Concept 105 in theme clinical. Identifier token d73610a3aa86620914e68b19918e2bb66ca8022e60f150280470c1c60613112f. Context markers: w66207 w50026 w84531 w91399 w17894 w89905 w23006 w37235. Sequence 105 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000106",
    "display" : "Bulk Clinical Observations concept 106 � 755900",
    "definition" : "Concept 106 in theme clinical. Identifier token 25b7e11bb5916c891167e7a1b5ff577870d2c2f35bea26d0d4035eb842280f89. Context markers: w37659 w44687 w96563 w20641 w30585 w41439 w32782 w82350. Sequence 106 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000107",
    "display" : "Bulk Clinical Observations concept 107 � 178711",
    "definition" : "Concept 107 in theme clinical. Identifier token ab7db81e1d3665bc88c6b43fecf6f695fafdb97d6a8a9b9073163237a6449ad2. Context markers: w30517 w10350 w63545 w69048 w87832 w71592 w48175 w14278. Sequence 107 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000108",
    "display" : "Bulk Clinical Observations concept 108 � 342720",
    "definition" : "Concept 108 in theme clinical. Identifier token 69c5338fc45a3ccc84f3798e1aaf13b4fd73049ef199e3b546b8182bfd40f76b. Context markers: w47762 w47056 w69510 w19329 w40595 w44675 w91927 w87304. Sequence 108 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000109",
    "display" : "Bulk Clinical Observations concept 109 � 793300",
    "definition" : "Concept 109 in theme clinical. Identifier token d6b4c633332b806760298fdba776c9dff9da68596370835a10f45140309b8afe. Context markers: w35928 w65723 w25043 w81376 w39466 w94886 w29528 w44816. Sequence 109 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000110",
    "display" : "Bulk Clinical Observations concept 110 � 966785",
    "definition" : "Concept 110 in theme clinical. Identifier token c3d0f4b2e73cc164224f60948147d8d08ef72df1b97ea8a0914f54af48cdbd9a. Context markers: w28643 w19359 w17816 w31747 w50319 w87993 w84607 w47828. Sequence 110 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000111",
    "display" : "Bulk Clinical Observations concept 111 � 560485",
    "definition" : "Concept 111 in theme clinical. Identifier token 0953abf3f1b64bbf7fce201f222b4ad630a8d8e0f3fe356c32bbff4c9149dc4a. Context markers: w26299 w71433 w49857 w62757 w45683 w75597 w80776 w74722. Sequence 111 of synthetic terminology for build pipeline load characterization and artifact size validation."
  },
  {
    "code" : "CLINICAL-000112",
    "display" : "Bulk Clinical Observations concept 112 � 559023",
    "definition" : "Concept 112 in theme clinical. Identifier token f3ff4ac5940e5524d7796c731896710689a67c2a8576253d97f0a1971dd9ad5d. Context markers: w20543 w88385 w15224 w66626 w52247 w89129 w42816 w13390. Sequence 112 of synthetic terminology for build pipeline load characterization and artifact size validation."
  }]
}

```
