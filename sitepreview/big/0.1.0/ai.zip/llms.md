# smart.who.int.big#0.1.0: null

## Pages

* [Home](index.md)
* [Downloads](downloads.md)
* [Data Models and Exchange](data-models-and-exchange.md)
* [Sequence Diagrams](sequence-diagrams.md)
* [Codings](codings.md)
* [System Actors](system-actors.md)
* [Non Functional Requirements](non-functional-requirements.md)
* [Business Process](business-process.md)
* [Changes](changes.md)
* [Feedback](feedback.md)
* [Indices](indices.md)
* [Functional Requirements](functional-requirements.md)
* [Testing](testing.md)
* [Indicators Measures](indicators-measures.md)
* [Scenarios](scenarios.md)
* [Artifacts Summary](artifacts.md)
* [System Requirements](system-requirements.md)
* [Trust Domain Policy](trust_domain_policy.md)
* [Business Requirements](business-requirements.md)
* [Test Data](test-data.md)
* [Adapting](adapting.md)
* [Decision Logic](decision-logic.md)
* [Deployment](deployment.md)
* [Maps](maps.md)
* [Security Privacy](security-privacy.md)
* [Business Processes](business-processes.md)
* [Concepts](concepts.md)
* [Dependencies](dependencies.md)
* [Reference Implementations](reference-implementations.md)
* [Trust Domain](trust_domain.md)
* [References](references.md)
* [Transactions](transactions.md)
* [Personas](personas.md)
* [Trust Domain Use Cases](trust_domain_use_cases.md)
* [Indicators](indicators.md)
* [Trust Domain Specifications](trust_domain_specifications.md)
* [Dictionary](dictionary.md)
* [License](license.md)

## Resources

### CodeSystems

* [Bulk Test CodeSystem � Clinical Observations](CodeSystem-bulk-test-cs-clinical.md)

### Resource Profiles

* [MyPatient](StructureDefinition-MyPatient.md)

### ImplementationGuides

* [largeIG](index.md)

### Examples

* [PatientExample (Patient)](Patient-PatientExample.md)
