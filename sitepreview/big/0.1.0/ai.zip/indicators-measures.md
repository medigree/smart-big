# Indicators Measures - v0.1.0

* [**Table of Contents**](toc.md)
* **Indicators Measures**

## Indicators Measures

The FHIR Measure is used to describe the indicator in a computable format. These indicators may be aggregated automatically from the digital tracking tool to populate a digital health management information system (HMIS).

Measures included in this implementation guide are listed in the [Artifact Index - Measures](artifacts.md)

For the operational descriptions of indicators and references, see the Digital Adaptation Kit (DAK) for **[insert health domain here]**, including Web Annex C of the DAK. Summary indicator content from the DAK is also represented in the [Indicators and Performance Metrics](indicators.md) page.

