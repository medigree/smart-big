# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/big/ImplementationGuide/smart.who.int.big | *Version*:0.1.0 |
| Draft as of 2026-04-25 | *Computable Name*:largeIG |

# largeIG

Feel free to modify this index page with your own awesome content!

